public class Conservator extends Innovator {

    private int childParam;


}
