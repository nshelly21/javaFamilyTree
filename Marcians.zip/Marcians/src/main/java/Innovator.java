import java.util.ArrayList;

public abstract class Innovator <T extends Innovator>  implements MartianCharacteristics{
    private int baseParam;

    private <T> 
    public  void setGeneticCode()
    {

    }

}
